
.. automodule:: G2DBinaryString
   :members:
   :inherited-members:


