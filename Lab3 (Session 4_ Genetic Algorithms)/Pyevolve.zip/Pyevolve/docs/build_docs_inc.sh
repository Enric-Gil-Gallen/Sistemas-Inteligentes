#!/bin/sh
sphinx-build -b html ./source ./build
